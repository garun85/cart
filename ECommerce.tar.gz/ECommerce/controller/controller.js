
		module.controller("HomeController", function($scope){
		$scope.users="Welcome to HomeController"

$scope.result1=0;
 $scope.cartqty=1;


		$scope.products=[
                    {
                        "id":12,
                        "brand":"itc",
                        "productName":"Bru",
                        "category":"Beverages",
                        "imageUrl":"../css/images/bru.jpg",
                        "slug": "bru",
                        "description": "Buy Online Bru Instant Coffee, 200 gm Pouch Pack in Chennai",
                        "prices": [
                                			{ "unit":"gm", 
                                              "weight":100,
                                              "stock":30,
                                              "actualPrice":30.00, 
                                              "sellingPrice":20.50
                                            },
                                			{
                                                "unit":"gm",
                                                "weight":500, 
                                                "stock":10,
                                                "actualPrice":50.00, 
                                                "sellingPrice":35.00
                                            },
                                			{
                                                "unit": "kg", 
                                                "weight":1, 
                                                "stock":4,
                                                "actualPrice":100.00, 
                                                "sellingPrice":60.00
                                            }

                                		]
                                                    
                	},

                    {
                        "id":22,
                        "brand":"Vegetables",
                        "productName":"Thoor dal", 
                        "category":"Dhals and pulses",
                        "imageUrl":"../css/images/thoordal.jpg", 
                        "slug": "thoor-dal", 
                        "description": "Toor dal is also sometimes referred to as lentils or split pigeon peas.",
                        "prices": [
                                			{ "unit":"gm", 
                                              "weight":100,
                                              "stock":10,
                                              "actualPrice":36.00, 
                                              "sellingPrice":25.00
                                            },
                                			{
                                                "unit":"gm",
                                                "weight":500, 
                                                "stock":1,
                                                "actualPrice":90.00, 
                                                "sellingPrice":85.00
                                            },
                                			{
                                                "unit": "kg", 
                                                "weight":1, 
                                                "stock":40,
                                                "actualPrice":180.00, 
                                                "sellingPrice":170.00
                                            }

                                	]    
                               
                    },

                    {
                        "id":32,
                        "brand":"Gold winner",
                        "productName":"Gold winner oil", 
                        "category":"oil",
                        "imageUrl":"../css/images/oil.png", 
                        "slug": "goldwinner-oil", 
                        "description": "Every drop of Gold winner not only glistens with quality",
                        "prices": [
                                			{ "unit":"gm", 
                                              "weight":500,
                                              "stock":30,
                                              "actualPrice":52.00, 
                                              "sellingPrice":48.00
                                            },
                                			{
                                                "unit":"kg",
                                                "weight":1, 
                                                "stock":10,
                                                "actualPrice":98.00, 
                                                "sellingPrice":95.00
                                            },
                                			{
                                                "unit": "kg", 
                                                "weight":5, 
                                                "stock":4,
                                                "actualPrice":475.00, 
                                                "sellingPrice":460.00
                                            }

                                	]    
                               
                    }
            ];



/*$scope.ins = function () 
  {
		localStorage.setItem("prd",JSON.stringify($scope.products1));
		//fetch();
		alert("hai");
  };

 
 $scope.fetch=function ()
 {
 	
 $scope.products=localStorage.getItem("prd"); 
 alert($scope.products);  
  
 }*/

 /*function rmv(){
 localStorage.setItem("cnt", "");
 fetch();
 }*/
 
$scope.Range = function(start, end) {
    var result = [];
    for (var i = start; i <= end; i++) {
        result.push(i);
    }
    return result;
};



$scope.mul = function() {
    //alert("hai"+$scope.selectedqty+","+$scope.selectedwei);
   
    $scope.result1 = 0;
    $scope.result1 = $scope.selectedqty * $scope.selectedwei;
   // alert("hai "+$scope.result1);
};

$scope.cnt=0;
$scope.cart=[];
$scope.addTocart=function(productIndex, selectedqty){
  
    var product = $scope.products[productIndex];
    product.qty = selectedqty;
    $scope.cart.splice(productIndex,1);
    $scope.cart.push(product);
    //$scope.cartqty = selectedqty;
     console.log(JSON.stringify($scope.cart));
    // console.log($scope.cart.length);
    $scope.cnt=$scope.cart.length;
    

}

$scope.removeitemcart=function(itemindex){

    $scope.cart.splice(itemindex,1);
    //console.log($scope.cart.length);
    $scope.cnt=$scope.cart.length;
}

$scope.getTotal=function(){

    var cart_total=0;
    angular.forEach($scope.cart,function(value){

        cart_total=cart_total+(value.prices[0].sellingPrice*value.qty) ;

    });
    return cart_total;
}


	});//controller ends here 

//onclick="addToCart('5447',document.getElementById('quantity_5447').value);" 