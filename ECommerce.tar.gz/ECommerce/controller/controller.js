
		module.controller("HomeController", function($scope){
		$scope.users="Welcome to HomeController"

		$scope.products=[
                    {
                        "brand":"itc",
                        "productName":"Bru",
                        "category":"Beverages",
                        "imageUrl":"../css/images/bru.jpg",
                        "slug": "bru",
                        "description": "Buy Online Bru Instant Coffee, 200 gm Pouch Pack in Chennai",
                        "pri":"Rs.50",
                        "prices": [
                                			{ "unit":"gm", 
                                              "weight":100,
                                              "stock":30,
                                              "actualPrice":25.00, 
                                              "sellingPrice":20.50
                                            },
                                			{
                                                "unit":"gm",
                                                "weight":500, 
                                                "stock":10,
                                                "actualPrice":50.00, 
                                                "sellingPrice":35.00
                                            },
                                			{
                                                "unit": "kg", 
                                                "weight":1, 
                                                "stock":4,
                                                "actualPrice":100.00, 
                                                "sellingPrice":60.00
                                            }

                                		]
                                                    
                	},

                    {
                        "brand":"Vegetables",
                        "productName":"Thoor dal", 
                        "category":"Dhals and pulses",
                        "imageUrl":"../css/images/thoordal.jpg", 
                        "slug": "thoor-dal", 
                        "description": "Toor dal is also sometimes referred to as lentils or split pigeon peas.",
                        "pri":"Rs.150",
                        "prices": [
                                			{ "unit":"gm", 
                                              "weight":100,
                                              "stock":30,
                                              "actualPrice":25.00, 
                                              "sellingPrice":20.50
                                            },
                                			{
                                                "unit":"gm",
                                                "weight":500, 
                                                "stock":10,
                                                "actualPrice":50.00, 
                                                "sellingPrice":35.00
                                            },
                                			{
                                                "unit": "kg", 
                                                "weight":1, 
                                                "stock":4,
                                                "actualPrice":100.00, 
                                                "sellingPrice":60.00
                                            }

                                	]    
                               
                    },

                    {
                        "brand":"Gold winner",
                        "productName":"Gold winner oil", 
                        "category":"oil",
                        "imageUrl":"../css/images/oil.png", 
                        "slug": "goldwinner-oil", 
                        "description": "Every drop of Gold winner not only glistens with quality and assures gourmet's delight.",
                        "pri":"Rs.90",
                        "prices": [
                                			{ "unit":"gm", 
                                              "weight":500,
                                              "stock":30,
                                              "actualPrice":52.00, 
                                              "sellingPrice":48.00
                                            },
                                			{
                                                "unit":"kg",
                                                "weight":1, 
                                                "stock":10,
                                                "actualPrice":98.00, 
                                                "sellingPrice":95.00
                                            },
                                			{
                                                "unit": "kg", 
                                                "weight":5, 
                                                "stock":4,
                                                "actualPrice":475.00, 
                                                "sellingPrice":460.00
                                            }

                                	]    
                               
                    }
            ];



/*$scope.ins = function () 
  {
		localStorage.setItem("prd",JSON.stringify($scope.products1));
		//fetch();
		alert("hai");
  };

 
 $scope.fetch=function ()
 {
 	
 $scope.products=localStorage.getItem("prd"); 
 alert($scope.products);  
  
 }*/

 /*function rmv(){
 localStorage.setItem("cnt", "");
 fetch();
 }*/
 




	});//controller ends here 