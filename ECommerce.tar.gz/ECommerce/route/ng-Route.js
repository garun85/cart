
       
       var myApp = angular.module('myApp', ['ngRoute']);
       
    
      myApp.config(['$routeProvider',
  			function($routeProvider) {
  			  $routeProvider.
   			   when('/main', {
    		    templateUrl: 'products/mainpage.html',
    		    controller: 'LoginController'
    		  }).
    		  when('/Home', {
     		   templateUrl: 'products/Home.html',
       			 controller: 'HomeController'
      		}).
      		when('/default', {
     		   templateUrl: 'products/Home.html',
       			 controller: 'DefaultController'
      		}).
     		 otherwise({
      		  redirectTo: '/default'
     	    });
      }]);
    
     
     myApp.controller('LoginController',function($scope,$http){
       $scope.name="Ajax using HTTP";
       
      
      $scope.Login=function(){
     
          var data={
             'uname': $scope.User,
			 'pwd' : $scope.Password,
          };
          
          $http.post('http://localhost/login/apiResponse.php',data).success(function(data,status){
            console.log(data);
          if(data.status==0){
		    alert(data.msg);
			document.location="#Home";
		  }
            
               
          });
          
      }
      
      /* $scope.myfun=function(){
       
           var dat={'page':'demo'};
         
         $http.post(
         'http://localhost/ag/apiResponse.php',dat).success(function(data,status){
           console.log(data);
         });
         
         
       }*/
       
       
     });
       
         myApp.controller('HomeController',function($scope){
        //  $scope.names=["Arun","Bala"];
          
       });
       
         myApp.controller('DefaultController',function($scope){
        //  $scope.names=["Arun","Bala"];
          
       });
