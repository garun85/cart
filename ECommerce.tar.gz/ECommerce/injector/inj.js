var injector = angular.injector(["ng","myApp"]);
var xyz=injector.get("validationFactory");