<?php

$postdata = file_get_contents("php://input");
$request = json_decode($postdata);



if($request->uname=="admin" && $request->pwd=="123"){
  // echo "Welcome Admin";
	
$ary=array(
  'status'=>'0',
  "msg"=>"Welcome admin"
);  

}
else
{
	$ary=array(
  'status'=>'1',
  "msg"=>"Login Failed!"
  ); 
}

echo json_encode($ary);




?>


 
