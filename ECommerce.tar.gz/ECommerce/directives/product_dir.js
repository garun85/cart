var mainApp = angular.module("myApp", []);

      mainApp.directive('productList', function() {
        var directive = {};
        directive.restrict = 'E';
        directive.template = "";

        directive.scope = {
          student : ""
        }

        directive.compile = function(element, attributes) {
          element.css("border", "1px solid #cccccc");

          var linkFunction = function($scope, element, attributes) {
            
            element.html();
            
          }
          return linkFunction;
        }

        return directive;
      });
