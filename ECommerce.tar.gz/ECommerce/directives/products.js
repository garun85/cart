var product =[
                    {
                        "brand":"itc",
                        "productName":"Bru",
                        "category":"Beverages",
                        "imageUrl":"/images/bru.jpg",
                        "slug": "bru",
                        "description": "Buy Online Bru Instant Coffee, 200 gm Pouch Pack in Chennai",
                                "price": [
                                			{ "unit":"gm", 
                                              "weight":"100",
                                              "stock":"30",
                                              "actualPrice":"25.00", 
                                              "sellingPrice":"20.50"
                                            },
                                			{
                                                "unit":"gm",
                                                "weight":"500", "stock":"10",
                                                "actualPrice":"50.00", 
                                                "sellingPrice":"35.00"
                                            },
                                			{
                                                "unit": "kg", 
                                                "weight":"1", 
                                                "stock":"4",
                                                "actualPrice":"100.00", 
                                                "sellingPrice":"60.00"
                                            }

                                		]
                	},

                    {

                        "brand":"Vegetables",
                        "productName":"Thoor dal", 
                        "category":"Dhals and pulses", 
                        "imageUrl":"/images/thoordal.jpg", 
                        "slug": "thoor-dal", "description": 
                        "Toor dal is also sometimes referred to as lentils or split pigeon peas. This traditional Indian dish is often served with rich spices over rice, and is a staple in many Indian restaurants and households. Toor dal is a member of the legume family, and this meal is not only delicious, it also has a number of health benefits.",
                                "price": [
                                			{
                                                "unit":"kg", 
                                                "weight":"1", 
                                                "stock":"30",
                                                "actualPrice":"25.00", 
                                                "sellingPrice":"20.50"
                                            },

                                			{
                                                "unit":"kg",
                                                "weight":"2", 
                                                "stock":"10",
                                                "actualPrice":"50.00", 
                                                "sellingPrice":"35.00"
                                            },

                                			{
                                                "unit": "kg",
                                                "weight":"5",
                                                "stock":"4",
                                                "actualPrice":"100.00",
                                                "sellingPrice":"60.00"
                                            }

                                		]
                    }
            ];


http://107.170.16.214/products/products/json

http://107.170.16.214/img/webimages/categories/Bru-Instant-Coffee-50-G-500x500-2889818172079834965.jpg

"Product": {
            "id": "24",
            "category_id": "8",
            "brand_id": "1",
            "name": "Bru",
            "slug": "bru",
            "description": "Buy Online Bru Instant Coffee, 200 gm Pouch Pack in Chennai",
            "image": "Bru-Instant-Coffee-50-G-500x500-2889818172079834965.jpg",
            "photo1": "bru-1657468371613259605.jpg",
            "photo2": "",
            "photo3": "",
            "photo4": "",
            "photo5": "",
            "price": "288.00",
            "weight": "1.00",
            "tags": null,
            "views": "152",
            "active": "1",
            "created": "2016-06-02 00:46:42",
            "modified": "2016-06-02 00:46:42"
        },
"Brand": {
            "id": "1",
            "name": "Burton",
            "slug": "burton",
            "active": "1",
            "created": "2012-12-06 00:00:00",
            "modified": "2012-12-06 00:00:00"
        }
    }, {
        "Product": {
            "id": "23",
            "category_id": "5",
            "brand_id": "8",
            "name": "Toor Dhal",
            "slug": "thoor-dhal",
            "description": "

                Toor dal is also sometimes referred to as lentils or split pigeon peas.This traditional Indian dish is often served with rich spices over rice,
            and is a staple in many Indian restaurants and households.Toor dal is a member of the legume family,
            and this meal is not only delicious,
            it also has a number of health benefits. < \/p>\r\n","image":"I044_Toor_Dal-620406766343570645.jpg","photo1":"I044_Toor_Dal2-2220739831668239445.JPG","photo2":"","photo3":"","photo4":"","photo5":"","price":"90.00","weight":"500.00","tags":"toor dhal","views":"178","active":"1","created":"2016-06-01 22:22:11","modified":"2016-06-01 22:38:09"},"Brand":{"id":"8","name":"Vegetables","slug":"vegetables","active":"1","created":"2016-06-01 22:19:14","modified":"2016-06-01 22:19:14"}}]