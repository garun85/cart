var product =[
                    {
                        "brand":"itc",
                        "productName":"Bru",
                        "category":"Beverages",
                        "imageUrl":"/images/bru.jpg",
                        "slug": "bru",
                        "description": "Buy Online Bru Instant Coffee, 200 gm Pouch Pack in Chennai",
                                "price": [
                                			{ "unit":"gm", 
                                              "weight":"100",
                                              "stock":"30",
                                              "actualPrice":"25.00", 
                                              "sellingPrice":"20.50"
                                            },
                                			{
                                                "unit":"gm",
                                                "weight":"500", "stock":"10",
                                                "actualPrice":"50.00", 
                                                "sellingPrice":"35.00"
                                            },
                                			{
                                                "unit": "kg", 
                                                "weight":"1", 
                                                "stock":"4",
                                                "actualPrice":"100.00", 
                                                "sellingPrice":"60.00"
                                            }

                                		]
                	},

                    {

                        "brand":"Vegetables",
                        "productName":"Thoor dal", 
                        "category":"Dhals and pulses", 
                        "imageUrl":"/images/thoordal.jpg", 
                        "slug": "thoor-dal", "description": 
                        "Toor dal is also sometimes referred to as lentils or split pigeon peas. This traditional Indian dish is often served with rich spices over rice, and is a staple in many Indian restaurants and households. Toor dal is a member of the legume family, and this meal is not only delicious, it also has a number of health benefits.",
                                "price": [
                                			{
                                                "unit":"kg", 
                                                "weight":"1", 
                                                "stock":"30",
                                                "actualPrice":"25.00", 
                                                "sellingPrice":"20.50"
                                            },

                                			{
                                                "unit":"kg",
                                                "weight":"2", 
                                                "stock":"10",
                                                "actualPrice":"50.00", 
                                                "sellingPrice":"35.00"
                                            },

                                			{
                                                "unit": "kg",
                                                "weight":"5",
                                                "stock":"4",
                                                "actualPrice":"100.00",
                                                "sellingPrice":"60.00"
                                            }

                                		]
                    }
            ];
