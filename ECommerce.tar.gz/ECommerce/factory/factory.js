	/*var module=angular.module("myApp",[]);
	module.factory("validationFactory",function(){
		return{
			nonEmptySet:function(val,label){
				if(val=="" || val==undefined){
				alert(label+' Must');
				}
			},
			
		
		}});*/
var module=angular.module("myApp",[]);