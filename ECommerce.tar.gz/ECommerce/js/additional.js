document.getElementById("btn_bgonclick").addEventListener("click", function onClick() {
    this.removeEventListener("click", onClick);
    
    this.style.backgroundColor = "#F03043";  
}, false);